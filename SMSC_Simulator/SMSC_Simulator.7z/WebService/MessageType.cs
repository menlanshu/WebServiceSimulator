﻿namespace WebServiceStudio
{
    using System;

    public enum MessageType
    {
        Begin,
        Success,
        Failure,
        Warning,
        Error
    }
}

