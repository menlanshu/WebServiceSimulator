﻿namespace WebServiceStudio
{
    public enum Language
    {
        CS,
        VB,
        Custom
    }
}

