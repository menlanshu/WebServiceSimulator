﻿namespace WebServiceStudio
{
    using System;

    public enum Protocol
    {
        SOAP,
        SOAP12,
        HttpGet,
        HttpPost
    }
}

